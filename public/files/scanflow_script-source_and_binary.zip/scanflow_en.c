#include <gtk/gtk.h>
#include <libudev.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
//#include <locale.h>
//#include <unistd.h>

#include <mntent.h>
#include <dirent.h>

//static void read_usb_data(char *picturesdir, GtkWidget *notice);
static char *get_mount_dir(GtkWidget *notice);
static int get_pictures_dirs(char *mount_dir, char ***dirlist, GtkWidget *notice);
/* This is a callback function. The data arguments are ignored
 *  * in this example. More on callbacks below. */
static void switch_page(GtkWidget *widget, GtkWidget **data)
{
	gtk_widget_hide(data[0]);
	gtk_widget_show(data[1]);
}

static int allowed_c(const char *s)
{
	while(isalnum(*s) || *s == '_' || *s == '-' || *s == '.' || *s == ' ')
		++s;
	return *s == '\0';	
}

static char *remove_space(const char *name)
{
	char *final;
	const char *t;

	t = name;

	final = malloc((strlen(name) + 1) * sizeof(char));

	while(*name != '\0')
	{
		if(*name == ' ')
		{
			*final = '_';
		} else
		{
			*final = *name;
		}
		name++;
		final++;
	}
	*final = '\0';

	return final - strlen(t);
}

static void transfer_files(GtkWidget *widget, GtkWidget **data)
{
	const char *textentrytext;
	char *dirname;
	char fulldirname[100] = {'\0'};
	char *home;
	char picturesdir[100] = {'\0'};
	char filepathfinal[150] = {'\0'};
	char filepathfinal2[150] = {'\0'};
	GtkWidget *notice;

	int i = 0;

	textentrytext = gtk_entry_get_text(GTK_ENTRY(((GtkBoxChild *) g_list_nth_data(((GtkBox *) data[0])->children, 5))->widget));
	notice = ((GtkBoxChild *) g_list_nth_data(((GtkBox *) data[0])->children, 8))->widget;

	//printf("%s\n", gtk_entry_get_text(GTK_ENTRY(((GtkBoxChild *) g_list_nth_data(((GtkBox *) data[0])->children, 5))->widget)));
	//printf("%s %d\n", textentrytext, strlen(textentrytext));

	if(strlen(textentrytext) == 0)
	{
		gtk_label_set_text(GTK_LABEL(notice), "First enter the name of the scanned book.");
		printf("First you need to enter the name of the scanned document/directory!\n");
		return;
	}
	if(allowed_c(textentrytext))
	{
		//printf("Svi su ispravni\n");
	} else
	{
		gtk_label_set_text(GTK_LABEL(notice), "The title contains characters that are not allowed. Following types of characters are allowed: numbers, English letters, hyphen, space, period.");
		printf("Characters not allowed\n");

		return;
	}

	home = getenv("HOME");

	dirname = remove_space(textentrytext);

//	if(data[3] == 0)
//	{
//		sprintf(fulldirname, "%s/Copy/zamjenske_slike/%s", home, dirname);
//
//		//printf("Fulldirname zamjenski: %s\n", fulldirname);
//
//		if(mkdir(fulldirname, 0775) == -1)
//		{
//			gtk_label_set_text(GTK_LABEL(notice), "Failed to create folder for replacement images");
//			printf("Replacement images directory cannot be created.\nMaybe there's no parent directory or\nI don't have //permissions to write into the directory!\n");
//			return;
//		}
//	}

	sprintf(fulldirname, "%s/Copy/%s", home, dirname);

	//printf("Fulldirname: %s\n", fulldirname);

	
	if(data[3] == 0)
	{
		if(mkdir(fulldirname, 0775) == -1)
		{
			gtk_label_set_text(GTK_LABEL(notice), "Failed to create a directory to store scans. Maybe there's no parent directory or\nI don't have the permission to write into the directory!\n");
			printf("Directory cannot be created.\nMaybe there's no parent directory or\n I don't have permissions to write into the directory\n");
			return;
		}
	}

	struct dirent **direlementlist;
	GError *error = NULL;
	int scandir_n = 0;
	float fract = 0;
	GdkPixbuf *step1, *step2;


	//read_usb_data(picturesdir, notice);
	//************************************************************
	//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
	
	int picnum = 0, piccount = 0;
	char *mount_dir;
	char **dirlist;
	int dirnum = 0, j = 0;

	mount_dir = get_mount_dir(notice);
	dirnum = get_pictures_dirs(mount_dir, &dirlist, notice);

	for(i = 0; i < dirnum; i++)
	{
		sprintf(picturesdir, "%s/DCIM/%s", mount_dir, dirlist[i]);
		picnum += -2 + scandir(picturesdir, &direlementlist, NULL, alphasort);	
	}
	//printf("pic %d\n", picnum);
	//exit(1);
	//scandir_n = scandir(picturesdir, &direlementlist, NULL, alphasort);

	gtk_label_set_text(GTK_LABEL(notice), "");
	g_object_set(((GtkBoxChild *) g_list_nth_data(((GtkBox *) data[0])->children, 5))->widget, "editable", FALSE, NULL);

	//fract = 1.0 / (scandir_n - 2);
	fract = 1.0 / picnum;
	gtk_progress_bar_set_fraction(GTK_PROGRESS_BAR(((GtkBoxChild *) g_list_nth_data(((GtkBox *) data[0])->children, 6))->widget), 0);
	gtk_widget_hide(((GtkBoxChild *) g_list_nth_data(((GtkBox *) data[0])->children, 7))->widget);
	gtk_widget_show(((GtkBoxChild *) g_list_nth_data(((GtkBox *) data[0])->children, 6))->widget);

	for(j = 0; j < dirnum; j++)
	{
		sprintf(picturesdir, "%s/DCIM/%s", mount_dir, dirlist[j]);
		scandir_n = scandir(picturesdir, &direlementlist, NULL, alphasort);	
	
		

	for(i = 2; i < scandir_n; i++)
	{
		sprintf(filepathfinal, "%s/%s", picturesdir, direlementlist[i]->d_name);
		if(data[3] == 0)
		{
			sprintf(filepathfinal2, "%s/page_%04d.jpg", fulldirname, 2 * piccount + 1);//2 * i - 3); //2*(i - 2)+1);
		} else
		{
			sprintf(filepathfinal2, "%s/page_%04d.jpg", fulldirname, 2 * (piccount + 1));//2 * (i - 1)); //2*(i - 2)+1);
		}
		printf("%s\n", filepathfinal);
		printf("%s\n", filepathfinal2);
		step1 = gdk_pixbuf_new_from_file(filepathfinal, &error);
		if(data[3] == 0)
		{
			step2 = gdk_pixbuf_rotate_simple(step1, 90);
		} else
		{
			step2 = gdk_pixbuf_rotate_simple(step1, 270);
		}
		gdk_pixbuf_save(step2, filepathfinal2, "jpeg", &error, "quality", "100", NULL);
		//mainpageimage = gtk_image_new_from_pixbuf(gdk_pixbuf_new_from_file_at_size(filepathfinal, 250, 250, &gerror));
		//gtk_box_pack_start(GTK_BOX(((GtkBoxChild *) g_list_nth_data(((GtkBox *) mainpageboxlayer)->children, 2))->widget), mainpageimage, FALSE, FALSE, 0);
		//gtk_widget_show(mainpageimage);
		g_object_unref(step1);
		g_object_unref(step2);
/////////
		if(remove(filepathfinal) != 0)
		{
			gtk_label_set_text(GTK_LABEL(notice), "Images from the card were not deleted. Delete the files from the card manually before you scan the next book.");
			printf("Images from the card were not deleted.\nDelete the files from the card manually before you scan the next book:\n%s\n", filepathfinal);
		}

		gtk_progress_bar_set_fraction(GTK_PROGRESS_BAR(((GtkBoxChild *) g_list_nth_data(((GtkBox *) data[0])->children, 6))->widget), fract * (piccount + 1));
		while (gtk_events_pending ())
			gtk_main_iteration ();

		piccount++;
	}
	}

	gtk_widget_hide(data[0]);
	if(data[3] == 0)
	{
		data[3] = (GtkWidget *) 1;
		//printf("na desnu: %d\n", data[3]);
		gtk_widget_show(data[1]);
	} else
	{
		data[3] = (GtkWidget *) 0;
		//printf("na lijevu: %d\n", data[3]);
		//gtk_widget_show(data[2]);
		gtk_widget_show(data[1]);
	}
}

static char *get_mount_dir(GtkWidget *notice)
{
	struct udev *udev;
	struct udev_enumerate *enumerate;
	struct udev_list_entry *devices, *dev_list_entry;
	struct udev_device *dev;
	const char *dev_node_path[10] = {NULL}, *temp_dev_node_path;

	struct mntent *mountent;
	FILE *fp;

	struct dirent *directoryent;
	DIR *dcimp, *wholep;

	//char picturesdir[100] = {'\0'};

	int i = 0;
	
	/* Create the udev object */
	udev = udev_new();
	if (!udev) {
		printf("Can't create udev\n");
		exit(1);
	}
	
	/* Create a list of the devices in the 'hidraw' subsystem. */
	enumerate = udev_enumerate_new(udev);
	//udev_enumerate_add_match_subsystem(enumerate, "scsi");
	udev_enumerate_add_match_subsystem(enumerate, "block");
	udev_enumerate_scan_devices(enumerate);
	devices = udev_enumerate_get_list_entry(enumerate);

	udev_list_entry_foreach(dev_list_entry, devices) {
		const char *path;
		
		/* Get the filename of the /sys entry for the device
 * 		   and create a udev_device object (dev) representing it */
		path = udev_list_entry_get_name(dev_list_entry);
		dev = udev_device_new_from_syspath(udev, path);

		/* usb_device_get_devnode() returns the path to the device node
 * 		   itself in /dev. */
		//printf("Device Node Path: %s\n", udev_device_get_devnode(dev));
		temp_dev_node_path = udev_device_get_devnode(dev);

		if(temp_dev_node_path == NULL)
		{
			continue;
		}

		dev = udev_device_get_parent_with_subsystem_devtype(dev, "usb", "usb_device");
		if (!dev) {
			//printf("Unable to find parent usb device.\n");
			continue;
			//exit(1);
		}

		dev_node_path[i] = temp_dev_node_path;
		i++;

	
		//printf("  VID/PID: %s %s\n", udev_device_get_sysattr_value(dev,"idVendor"), udev_device_get_sysattr_value(dev, "idProduct"));
		//printf("  %s\n  %s\n", udev_device_get_sysattr_value(dev,"manufacturer"), udev_device_get_sysattr_value(dev,"product"));
		//printf("  serial: %s\n", udev_device_get_sysattr_value(dev, "serial"));
		udev_device_unref(dev);
	}
	/* Free the enumerator object */
	udev_enumerate_unref(enumerate);

	udev_unref(udev);
	int j = 0;
	
	if (i == 0)
	{
		gtk_label_set_text(GTK_LABEL(notice), "You haven't inserted the SD card!");
		printf("You haven't inserted the SD card.\n");
		return;
		//exit(1);
	} else
	{
		for(j = 0; j < i; j++)
		{
			printf("%s\n", dev_node_path[j]);
		}
	}

	fp = setmntent("/etc/mtab", "r");
	if(fp == NULL)
	{
		//gtk_label_set_text(GTK_LABEL(notice), "No such file or directory!");
		printf("No such file or directory!\n");
		exit(1);
	}

	int m = 0;
	while(mountent = getmntent(fp))
	{
		for(j = 0; j < i; j++)
		{
			if(strcmp(mountent->mnt_fsname, dev_node_path[j]) == 0) //dev_node_path[0]) == 0)
			{
				//printf("%s %s\n", mountent->mnt_fsname, mountent->mnt_dir);
				//j = 0;
				m = -1;
				break;
			}
		}
		if(m == -1)
		{
			break;
		}
	}

	if(m == 0)
	{
		gtk_label_set_text(GTK_LABEL(notice), "Card is inserted, but not mounted. Try re-inserting it!");
		printf("Card is inserted, but not mounted. Try re-inserting it!\n");
		return;
		//exit(1);
	}

	endmntent(fp);

	char *ret;
	ret = malloc(sizeof(char) * (strlen(mountent->mnt_dir) + 1));
	strcpy(ret, mountent->mnt_dir);


	//printf("%s\n", ret);
	//exit(1);

	return ret;
}

static int get_pictures_dirs(char *mount_dir, char ***dirlist, GtkWidget *notice)
{
	char picturesdir[150] = {'\0'};
	char **temp_dirlist, **dirlistloc = NULL;
	char *temp_dir;
	int dir_num = 0;

	sprintf(picturesdir, "%s/DCIM", mount_dir);

	int scandir_n = 0, k = -1, j = 0;
	struct dirent **direlementlist;

	scandir_n = scandir(picturesdir, &direlementlist, NULL, alphasort);

	if(scandir_n == -1)
	{
		//gtk_label_set_text(GTK_LABEL(notice), "Greška kod čitanja direktorija slika.\n");
		printf("Error in reading directory %s.\n", picturesdir);
		exit(1);
	} else
	{
		for(j = 0; j < scandir_n; j++)
		{
			printf("%s\n", direlementlist[j]->d_name);
			if(strstr(direlementlist[j]->d_name, "CANON") != NULL)
			{
				dir_num++;
				k = j;

				temp_dir = malloc(sizeof(char) * (strlen(direlementlist[j]->d_name) + 1));
				strcpy(temp_dir, direlementlist[j]->d_name);

				//printf("%d\n", sizeof(char) * dir_num);

				temp_dirlist = realloc(dirlistloc, sizeof(char) * dir_num);
				if(temp_dirlist == NULL)
				{
					continue;
				}
				else
				{
					dirlistloc = temp_dirlist;
				}
				dirlistloc[dir_num - 1] = temp_dir;
			}
		}
	}

	if(k == -1)
	{
		gtk_label_set_text(GTK_LABEL(notice), "There's no *CANON directory.");
		printf("There's no *CANON directory.\n");
		exit(1);
		
	}

	/*for(j = 0; j < dir_num; j++)
	{
		printf("%s\n", dirlist[j]);
	}
	exit(1);*/



	//sprintf(picturesdir, "%s/%s/", picturesdir, direlementlist[k]->d_name);

	*dirlist = dirlistloc;

	return dir_num;
	//return direlementlist;

	//return picturesdir;
}

static void insert_sd_card(GtkWidget *widget, GtkWidget **data)
{
	GtkWidget *leftpageboxlayer, *mainpageboxlayer;
	GtkWidget *mainpageimage;
	GtkWidget *page_switch, *notice;
	
	page_switch = data[2];

	//printf("page switch: %d\n", page_switch);
	

	//DIR *pictd;
	struct dirent **direlementlist;
	
	char picturesdir[100] = {'\0'};

	GError *gerror = NULL;


	leftpageboxlayer = data[0];
	mainpageboxlayer = data[1];

	notice = ((GtkBoxChild *) g_list_nth_data(((GtkBox *) data[0])->children, 3))->widget;

	//read_usb_data(picturesdir, notice);
	char *mount_dir;
	char **dirlist;
	int i = 0, k = 0;
	int dirnum = 0, j = 0;
	mount_dir = get_mount_dir(notice);
	dirnum = get_pictures_dirs(mount_dir, &dirlist, notice);

	/*for(j = 0; j < dirnum; j++)
	{
		printf("%d. %s\n", j + 1, dirlist[j]);
	}
	exit(1);*/

	//printf("Vratio je %s\n", picturesdir);
	
//((GtkBoxChild *) g_list_nth_data(((GtkBox *) leftpageboxlayer)->children, 1))->widget
	//int i;
	//for(i = 0; i < 4; i++){
	
	int scandir_n = 0, scandirlast = 0;
	char filepathfinal[150]= {'\0'};
	char piclist[8][150], fr[150] = {'\0'}, sc[150] = {'\0'}, th[150] = {'\0'}, fo[150] = {'\0'};
	GdkPixbuf *step1, *step2;

	//scandir_n = scandir(picturesdir, &direlementlist, NULL, alphasort);
	
	for(j = 0; j < dirnum; j++)
	{
		sprintf(picturesdir, "%s/DCIM/%s", mount_dir, dirlist[j]);
		//printf("dir %s\n", picturesdir);
		scandir_n = scandir(picturesdir, &direlementlist, NULL, alphasort);
		if(scandir_n == -1)
		{
			printf("Directory failed to open %s\n", picturesdir);
			return;
		} else if(scandir_n >= 8)
		{
			scandirlast = 1;
			//printf("slika %d\n", scandir_n);
			for(i = 2; i < scandir_n; i++)
			{
				if(k < 4)
				{
					sprintf(piclist[k], "%s/%s", picturesdir, direlementlist[i]->d_name);
					k++;
				}
				strcpy(fr, sc);
				strcpy(sc, th);
				strcpy(th, fo);
				sprintf(fo, "%s/%s", picturesdir, direlementlist[i]->d_name);
			}
		}
	}

	strcpy(piclist[4], fr);
	strcpy(piclist[5], sc);
	strcpy(piclist[6], th);
	strcpy(piclist[7], fo);

	if(scandirlast == 0)
	{
		gtk_label_set_text(GTK_LABEL(notice), "No images found on the card. Have you inserted the same card twice?");
		printf("Directory is empty, images were not found on the card.\nHave you inserted the same card twice?\n");
		return;
	}

	/*for(j = 0; j < 8; j++)
	{
		printf("slika: %s\n", piclist[j]);
	}
	exit(1);*/


	gtk_progress_bar_set_fraction(GTK_PROGRESS_BAR(((GtkBoxChild *) g_list_nth_data(((GtkBox *) data[0])->children, 2))->widget), 0);
	gtk_widget_hide(((GtkBoxChild *) g_list_nth_data(((GtkBox *) data[0])->children, 1))->widget);
	gtk_widget_show(((GtkBoxChild *) g_list_nth_data(((GtkBox *) data[0])->children, 2))->widget);

	int angle = 0;
	GList *children1, *children2, *iter1, *iter2;

	if(page_switch == 0)
	{
		angle = 90;
		g_object_set(((GtkBoxChild *) g_list_nth_data(((GtkBox *) data[1])->children, 5))->widget, "editable", TRUE, NULL);
	} else
	{
		angle = 270;
		children1 = gtk_container_get_children(GTK_CONTAINER(((GtkBoxChild *) g_list_nth_data(((GtkBox *) data[1])->children, 2))->widget));
		children2 = gtk_container_get_children(GTK_CONTAINER(((GtkBoxChild *) g_list_nth_data(((GtkBox *) data[1])->children, 3))->widget));
		for(iter1 = children1, iter2 = children2; iter1 != NULL; iter1 = g_list_next(iter1), iter2 = g_list_next(iter2))
		{
			gtk_widget_destroy(GTK_WIDGET(iter1->data));
			gtk_widget_destroy(GTK_WIDGET(iter2->data));
		}
		g_list_free(children1);
		g_list_free(children2);

		g_object_set(((GtkBoxChild *) g_list_nth_data(((GtkBox *) data[1])->children, 5))->widget, "editable", FALSE, NULL);
		gtk_widget_hide(((GtkBoxChild *) g_list_nth_data(((GtkBox *) data[1])->children, 6))->widget);
		gtk_widget_show(((GtkBoxChild *) g_list_nth_data(((GtkBox *) data[1])->children, 7))->widget);
	}

	for(i = 0; i < 4; i++)
	{
		//sprintf(filepathfinal, "%s%s", picturesdir, direlementlist[i+2]->d_name);
		//printf("%s\n", filepathfinal);
		//mainpageimage = gtk_image_new_from_pixbuf(gdk_pixbuf_rotate_simple(gdk_pixbuf_new_from_file_at_size(filepathfinal, 250, 250, &gerror), 90));
		step1 = gdk_pixbuf_new_from_file_at_size(piclist[i], 250, 250, &gerror);
		step2 = gdk_pixbuf_rotate_simple(step1, angle);
		mainpageimage = gtk_image_new_from_pixbuf(step2);
		//mainpageimage = gtk_image_new_from_pixbuf(gdk_pixbuf_new_from_file_at_size(filepathfinal, 250, 250, &gerror));
		gtk_box_pack_start(GTK_BOX(((GtkBoxChild *) g_list_nth_data(((GtkBox *) mainpageboxlayer)->children, 2))->widget), mainpageimage, FALSE, FALSE, 0);
		gtk_widget_show(mainpageimage);

		g_object_unref(step1);
		g_object_unref(step2);
		
		gtk_progress_bar_set_fraction(GTK_PROGRESS_BAR(((GtkBoxChild *) g_list_nth_data(((GtkBox *) data[0])->children, 2))->widget), 0.125 * (2*i + 1));
		while (gtk_events_pending ())
		gtk_main_iteration ();


		//sprintf(filepathfinal, "%s%s", picturesdir, direlementlist[scandir_n - 4 + i]->d_name);
		//printf("%s\n", filepathfinal);
		//mainpageimage = gtk_image_new_from_pixbuf(gdk_pixbuf_rotate_simple(gdk_pixbuf_new_from_file_at_size(filepathfinal, 250, 250, &gerror), 90));
		step1 = gdk_pixbuf_new_from_file_at_size(piclist[i + 4], 250, 250, &gerror);
		step2 = gdk_pixbuf_rotate_simple(step1, angle);
		mainpageimage = gtk_image_new_from_pixbuf(step2);
		//mainpageimage = gtk_image_new_from_pixbuf(gdk_pixbuf_new_from_file_at_size(filepathfinal, 250, 250, &gerror));
		gtk_box_pack_start(GTK_BOX(((GtkBoxChild *) g_list_nth_data(((GtkBox *) mainpageboxlayer)->children, 3))->widget), mainpageimage, FALSE, FALSE, 0);
		gtk_widget_show(mainpageimage);
		
		g_object_unref(step1);
		g_object_unref(step2);

		gtk_progress_bar_set_fraction(GTK_PROGRESS_BAR(((GtkBoxChild *) g_list_nth_data(((GtkBox *) data[0])->children, 2))->widget), 2 * 0.125 * (i + 1));
		while (gtk_events_pending ())
		gtk_main_iteration ();
	}

	gtk_widget_hide(data[0]);
	gtk_widget_show(data[1]);
}

static gboolean delete_event(GtkWidget *widget, GdkEvent *event, gpointer data)
{
    /* If you return FALSE in the "delete-event" signal handler,
 *      * GTK will emit the "destroy" signal. Returning TRUE means
 *           * you don't want the window to be destroyed.
 *                * This is useful for popping up 'are you sure you want to quit?'
 *                     * type dialogs. */

    // g_print ("delete event occurred\n");

    /* Change TRUE to FALSE and the main window will be destroyed with
 *      * a "delete-event". */

	return FALSE;
}

static void destroy(GtkWidget *widget, gpointer data)
{
	gtk_main_quit();
}

static GtkWidget *create_left_layer()
{
	GtkWidget *leftpageboxlayer;

	GtkWidget *leftpagelabel;
	GtkWidget *leftpagenoticelabel;
	GtkWidget *leftpagebutton;

	GtkWidget *progressbar;

	// create left page box layer
	leftpageboxlayer = gtk_vbox_new(FALSE, 0);

	// create left page label
	leftpagelabel = gtk_label_new("Insert the card from the right camera and press \"Read\"");
	gtk_box_pack_start(GTK_BOX(leftpageboxlayer), leftpagelabel, FALSE, FALSE, 0);
	gtk_widget_show(leftpagelabel);

	// create left page button
	leftpagebutton = gtk_button_new_with_label("Read");
	gtk_box_pack_start(GTK_BOX(leftpageboxlayer), leftpagebutton, FALSE, FALSE, 0);
	gtk_widget_show(leftpagebutton);

	//read_usb_data();
	progressbar = gtk_progress_bar_new();
	gtk_box_pack_start(GTK_BOX(leftpageboxlayer), progressbar, FALSE, FALSE, 0);
	//gtk_widget_show(progressbar);

	leftpagenoticelabel = gtk_label_new("");
	gtk_box_pack_start(GTK_BOX(leftpageboxlayer), leftpagenoticelabel, FALSE, FALSE, 0);
	gtk_widget_show(leftpagenoticelabel);

	return leftpageboxlayer;
}

static GtkWidget *create_right_layer()
{
	GtkWidget *rightpageboxlayer;

	GtkWidget *rightpagelabel;
	GtkWidget *rightpagenoticelabel;
	GtkWidget *rightpagebutton;

	GtkWidget *progressbar;

	// create right page box layer
	rightpageboxlayer = gtk_vbox_new(FALSE, 0);

	// create right page label
	rightpagelabel = gtk_label_new("Insert the card from the left camera and press \"Read\"!");
	gtk_box_pack_start(GTK_BOX(rightpageboxlayer), rightpagelabel, FALSE, FALSE, 0);
	gtk_widget_show(rightpagelabel);

	// create right page button
	rightpagebutton = gtk_button_new_with_label("Read");
	gtk_box_pack_start(GTK_BOX(rightpageboxlayer), rightpagebutton, FALSE, FALSE, 0);
	gtk_widget_show(rightpagebutton);

	progressbar = gtk_progress_bar_new();
	gtk_box_pack_start(GTK_BOX(rightpageboxlayer), progressbar, FALSE, FALSE, 0);

	rightpagenoticelabel = gtk_label_new("");
	gtk_box_pack_start(GTK_BOX(rightpageboxlayer), rightpagenoticelabel, FALSE, FALSE, 0);
	gtk_widget_show(rightpagenoticelabel);

	return rightpageboxlayer;
}

static GtkWidget *create_main_layer()
{
	GtkWidget *mainpageboxlayer;
	
	GtkWidget *mainpagebutton1;
	GtkWidget *mainpagebutton2;
	GtkWidget *mainpagelabel1;
	GtkWidget *mainpagelabel2;
	GtkWidget *mainpagenoticelabel;
	GtkWidget *mainpagetoplabel;
	GtkWidget *mainpagemiddlelabel;

	GtkWidget *topimagerowbox;
	GtkWidget *bottomimagerowbox;

	//GdkPixbuf *mainpagepixbuf;
	//GtkWidget *mainpageimage;

	GtkWidget *textentry;
	GtkWidget *progressbar;

	//GError *gerror = NULL;


	// create main page box layer
	mainpageboxlayer = gtk_vbox_new(FALSE, 0);
	
	// create main page labels
	mainpagetoplabel = gtk_label_new("Memory card - L");
	gtk_box_pack_start(GTK_BOX(mainpageboxlayer), mainpagetoplabel, FALSE, FALSE, 0);
	//gtk_widget_show(mainpagetoplabel);

	mainpagemiddlelabel = gtk_label_new("First and last four images");
	gtk_box_pack_start(GTK_BOX(mainpageboxlayer), mainpagemiddlelabel, FALSE, FALSE, 0);
	gtk_widget_show(mainpagemiddlelabel);

	topimagerowbox = gtk_hbox_new(FALSE, 0);
	bottomimagerowbox = gtk_hbox_new(FALSE, 0);

	/*int i = 0;

	// create image rows
	for(i = 0; i < 4; i++)
	{
		mainpageimage = gtk_image_new_from_pixbuf(gdk_pixbuf_new_from_file_at_size("/home/mislav/Logo_vertikal_RGB.jpg", 80, 80, &gerror));
		gtk_box_pack_start(GTK_BOX(topimagerowbox), mainpageimage, FALSE, FALSE, 0);
		gtk_widget_show(mainpageimage);

		mainpageimage = gtk_image_new_from_pixbuf(gdk_pixbuf_new_from_file_at_size("/home/mislav/Logo_vertikal_RGB.jpg", 80, 80, &gerror));
		gtk_box_pack_start(GTK_BOX(bottomimagerowbox), mainpageimage, FALSE, FALSE, 0);
		gtk_widget_show(mainpageimage);
	}*/

	
	gtk_box_pack_start(GTK_BOX(mainpageboxlayer), topimagerowbox, FALSE, FALSE, 0);
	gtk_widget_show(topimagerowbox);
	gtk_box_pack_start(GTK_BOX(mainpageboxlayer), bottomimagerowbox, FALSE, FALSE, 0);
	gtk_widget_show(bottomimagerowbox);

	mainpagebutton1 = gtk_button_new_with_label("Delete excess photos");
	gtk_box_pack_start(GTK_BOX(mainpageboxlayer), mainpagebutton1, FALSE, FALSE, 0);
	//gtk_widget_show(mainpagebutton1);

	textentry = gtk_entry_new();
	gtk_box_pack_start(GTK_BOX(mainpageboxlayer), textentry, FALSE, FALSE, 0);
	gtk_entry_set_text (GTK_ENTRY(textentry), "================== Enter the name of the book! ==================");
	gtk_widget_show(textentry);

	progressbar = gtk_progress_bar_new();
	gtk_box_pack_start(GTK_BOX(mainpageboxlayer), progressbar, FALSE, FALSE, 0);

	mainpagebutton2 = gtk_button_new_with_label("Transfer the photos");
	gtk_box_pack_start(GTK_BOX(mainpageboxlayer), mainpagebutton2, FALSE, FALSE, 0);
	gtk_widget_show(mainpagebutton2);

	mainpagenoticelabel = gtk_label_new("");
	gtk_box_pack_start(GTK_BOX(mainpageboxlayer), mainpagenoticelabel, FALSE, FALSE, 0);
	gtk_widget_show(mainpagenoticelabel);

	return mainpageboxlayer;
}

int main(int argc, char *argv[])
{
	/* GtkWidget is the storage type for widgets */
	GtkWidget *window;

	GtkWidget *globalcontainterbox;

	GtkWidget *leftpageboxlayer;
	GtkWidget *rightpageboxlayer;
	GtkWidget *mainpageboxlayer;

	GtkWidget *datapassleft[3], *datapassright[3], *datapassmain[4];


	gtk_init(&argc, &argv);

	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

	/* When the window is given the "delete-event" signal (this is given
	*      * by the window manager, usually by the "close" option, or on the
	*           * titlebar), we ask it to call the delete_event () function
	*                * as defined above. The data passed to the callback
	*                     * function is NULL and is ignored in the callback function. */
	g_signal_connect(window, "delete-event", G_CALLBACK(delete_event), NULL);

	/* Here we connect the "destroy" event to a signal handler.  
	*      * This event occurs when we call gtk_widget_destroy() on the window,
	*           * or if we return FALSE in the "delete-event" callback. */
	g_signal_connect(window, "destroy",
			  G_CALLBACK(destroy), NULL);

	/* Sets the border width of the window. */
	gtk_container_set_border_width (GTK_CONTAINER (window), 10);

	/* Creates a new button with the label "Hello World". */
	// button = gtk_button_new_with_label ("Hello World");


	/* This will cause the window to be destroyed by calling
	*      * gtk_widget_destroy(window) when "clicked".  Again, the destroy
	*           * signal could come from here, or the window manager. */
	// g_signal_connect_swapped (button, "clicked", G_CALLBACK (gtk_widget_destroy), window);

	
	// create globalbox that contains all other visible and invisible boxes
	globalcontainterbox = gtk_vbox_new(FALSE, 0);
	gtk_widget_show(globalcontainterbox);

	leftpageboxlayer = create_left_layer();
	
	gtk_box_pack_start(GTK_BOX(globalcontainterbox), leftpageboxlayer, FALSE, FALSE, 0);
	gtk_widget_show(leftpageboxlayer);	
	
	rightpageboxlayer = create_right_layer();
	gtk_box_pack_start(GTK_BOX(globalcontainterbox), rightpageboxlayer, FALSE, FALSE, 0);

	mainpageboxlayer = create_main_layer();
	gtk_box_pack_start(GTK_BOX(globalcontainterbox), mainpageboxlayer, FALSE, FALSE, 0);


	/* When the button receives the "clicked" signal, it will call the
	*      * function hello() passing it NULL as its argument.  The hello()
	*           * function is defined above. */
	datapassleft[0] = leftpageboxlayer;
	datapassleft[1] = mainpageboxlayer;
	datapassleft[2] = (GtkWidget *) 0;
	//g_signal_connect(leftpagebutton, "clicked", G_CALLBACK(switch_page), datapassleft);
	//GtkWidget *nekaj = ((GtkBoxChild *) g_list_nth_data(((GtkBox *) leftpageboxlayer)->children, 1))->widget;
	//g_signal_connect(g_list_nth_data(((GtkBox *) leftpageboxlayer)->children, 1), "clicked", G_CALLBACK(switch_page), datapassleft);
	g_signal_connect(((GtkBoxChild *) g_list_nth_data(((GtkBox *) leftpageboxlayer)->children, 1))->widget, "clicked", G_CALLBACK(insert_sd_card), datapassleft);
	
	datapassright[0] = rightpageboxlayer;
	datapassright[1] = mainpageboxlayer;
	datapassright[2] = (GtkWidget *) 1;
	//g_signal_connect(rightpagebutton, "clicked", G_CALLBACK(switch_page), datapassright);
	g_signal_connect(((GtkBoxChild *) g_list_nth_data(((GtkBox *) rightpageboxlayer)->children, 1))->widget, "clicked", G_CALLBACK(insert_sd_card), datapassright);
	
	
	datapassmain[0] = mainpageboxlayer;
	datapassmain[1] = rightpageboxlayer;
	datapassmain[2] = leftpageboxlayer;
	datapassmain[3] = (GtkWidget *) 0;
	g_signal_connect(((GtkBoxChild *) g_list_nth_data(((GtkBox *) mainpageboxlayer)->children, 7))->widget, "clicked", G_CALLBACK(transfer_files), datapassmain);
	

	/* This packs the button into the window (a gtk container). */
	gtk_container_add(GTK_CONTAINER(window), globalcontainterbox);

	/* and the window */
	gtk_widget_show(window);

	/* All GTK applications must have a gtk_main(). Control ends here
	*      * and waits for an event to occur (like a key press or
	*           * mouse event). */
	gtk_main();

	return 0;
}

