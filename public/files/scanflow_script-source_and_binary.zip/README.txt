This is a custom C++ script written by Mislav Stublić to facilitate the transfer, renaming, rotating and collating of the images in the two-cameras scanning setup.

The script prompts the user to place into a card reader connected to the computer first the memory card from the right camera, provides a preview of the first and last four images and provides an entry field to create a sub-folder in a local cloud storage folder (path: /home/[username]/Copy). It transfers, renames, rotates the files, deletes them from the card and prompts the user to replace the card with the one from the left camera in order to the transfer the files that card and place them in the same folder. 

The script was created to a run on a GNU/Linux system.

If you have other cameras than Canon, you can edit the line 387 of the source file to change to the naming convention of your cameras. Script looks for /home/[user]/Copy folder. Create such a folder, or edit the line 112 to point to the folder where you want the script to store your files. Recompile by running the following command in your terminal: "gcc scanflow.c -o scanflow -ludev `pkg-config --cflags --libs gtk+-2.0`".


